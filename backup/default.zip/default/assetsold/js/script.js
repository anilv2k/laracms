document.addEventListener('DOMContentLoaded', function() {
    
    //alert("Ready!");

}, false);