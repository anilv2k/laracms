<!DOCTYPE html>
<html lang="en">

    <head>
        {!! meta_init() !!}
        <meta name="keywords" content="@get('keywords')">
        <meta name="description" content="@get('description')">
        <meta name="author" content="@get('author')">
    
        <title>@get('title')</title>

        @styles()
        
    </head>

    <body>
        @partial('header')
      <section class="banner-section position-relative">
                <div class="container">
                    <div class="banner-content py-5">
                        <div class="position-relative">
                            <input type="search" class="banner-search form-control" placeholder="What do you want to learn?">
                            <i class="fa fa-search"></i>
                        </div>
                        <h2 class="banner-title py-3 mb-2">Learn on your Schedule</h2>
                        <p class="mb-3">Study any topic, anytime. Explore thousands <br>of courses for the lowest ever!</p>
                        <button class="btn custom-primary-btn btn-medium">Start Learning!</button>
                    </div>
                </div>
                <div class="features">
                    <div class="container">
                        <div class="d-flex f-wrap">
                            <div class="feature">
                                <img src="@asset("images/radio.png")" width="30">
                                <h6>12 Online Courses</h6>
                                <p>Explore a variety of fresh topics</p>
                            </div>
                           
                            <div class="feature">
                                <img src="@asset("images/correct.png")" width="30">
                                <h6>Teste</h6>
                                <p>Find the right course of you</p>
                            </div>
                            <div class="feature">
                                <img src="@asset("images/clock.png")" width="30">
                                <h6>12 Online Courses</h6>
                                <p>Learn your schedule</p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
			
		
            <section class="popular-topics py-5">
			
				<?php $params=array('users' => 10,'Name'=>'Anil Kumar'); ?>
				{{ Widget::run('Modules\Courses\Widgets\recentCourses',$params) }} 
				
            </section>

            <section class="middle-strip py-5 text-center">
                <h5 class="mb-2">Get Personalized Recommendations</h5>
                <p>Answer few questions for your top picks</p>
                <button class="btn custom-primary-btn btn-medium mt-3">Get started</button>
            </section>

            <section class="about-section py-5">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="p-5">
                                <img src="@asset("images/about-img.png")" class="img-fluid">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="about-content">
                                <h3 class="mb-3 about-title">About Learning Management System</h3>
                                <p>
                                    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Totam ratione incidunt 
                                    distinctio nemo officia debitis non et, ex voluptas! Quis, 
                                    ex excepturi adipisci ut ipsam et quos recusandae! Sapiente, recusandae?
                                    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Totam ratione incidunt 
                                    distinctio nemo officia debitis non et, ex voluptas! Quis, 
                                    ex excepturi adipisci ut ipsam et quos recusandae! Sapiente, recusandae?
                                </p>
                                <button class="btn custom-primary-btn btn-medium mt-3">Know More</button>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </section>

            <section class="objectives-section py-5">
                <div class="container">
                    <h3 class="text-center mb-5 obj-header position-relative">Objectives</h3>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="objective text-center">
                                <div class="obj-img mb-3">
                                    <img src="@asset("images/book.png")">
                                </div>
                                <h4 class="mb-3 objective-title">Personalized learning</h4>
                                <p>
                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet neque 
                                    tempore odio sunt velit quis doloribus, alias, nesciunt maxime, accusantium modi voluptatem 
                                    praesentium inventore voluptatum sit dolorum voluptas commodi consequuntur!
                                </p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="objective text-center">
                                <div class="obj-img mb-3">
                                    <img src="@asset("images/content.png")">
                                </div>
                                <h4 class="mb-3 objective-title">Trusted Content</h4>
                                <p>
                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet neque 
                                    tempore odio sunt velit quis doloribus, alias, nesciunt maxime, accusantium modi voluptatem 
                                    praesentium inventore voluptatum sit dolorum voluptas commodi consequuntur!
                                </p>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="objective text-center">
                                <div class="obj-img mb-3">
                                    <img src="@asset("images/growth.png")">
                                </div>
                                <h4 class="mb-3 objective-title">Tools to empower teachers</h4>
                                <p>
                                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet neque 
                                    tempore odio sunt velit quis doloribus, alias, nesciunt maxime, accusantium modi voluptatem 
                                    praesentium inventore voluptatum sit dolorum voluptas commodi consequuntur!
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>	
        
        @partial('footer')

        @scripts()
    </body>

</html>
