<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>iLMS</title>
        <link rel="icon" href="@asset("img/favicon.ico")" type="image/png">
        <!-- Bootstrap core CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
        <link href="https://fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,500,500i,700,700i,900&display=swap" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="@asset("css/reset.css")">
        <link rel="stylesheet" type="text/css" href="@asset("css/custom.css")">
    </head>
    <body>
        <header>
            <div class="container">
                <nav class="navbar navbar-expand-md navbar-light py-2 p-0">
                    <a class="navbar-brand p-0" href="{{ url('/') }}"><img src="@asset("images/logo.png")"></a>
                    
                    <ul class="navbar-nav mr-auto">
                        
                        <li class="nav-item">
                            <a class="nav-link d-flex" href="{{ url('/courses') }}" tabindex="-1"> <img src="@asset("images/grid.png")" width="16" class="mr-2"> 
                                <span class=" d-none d-md-block">Courses</span></a>
                        </li>
                        <li class="nav-item px-3">
                            <div class="position-relative d-none d-md-block">
                                <input type="search" placeholder="Search..." class="form-control search">
                                <i class="fa fa-search color-primary"></i>
                            </div>    
                        </li>
                    </ul>

                    <ul class="navbar-nav ml-auto">
                        
                        <li class="nav-item">
                            <a class="nav-link" href="{{ url('/user/dashboard') }}" tabindex="-1">Dashboard</a>
                        </li>
						
						<li class="nav-item">
                            <a class="nav-link" href="{{ url('/user/mycourses') }}" tabindex="-1">My Courses</a>
                        </li>
                        
                    </ul>
                        
                        <!-- <ul class="navbar-nav ml-auto">
                         
                            <li class="nav-item">
                                <a class="mr-3 btn custom-primary-btn btn-medium" href="#!" tabindex="-1">Login</a>
                            </li>
                            
                            <li class="nav-item">
                                <a class=" btn custom-primary-btn btn-medium" href="#!" tabindex="-1">Signup</a>
                            </li>
                            
                        </ul> -->
                
                    <li class="nav-item dropdown ">
                        <a class="nav-link dropdown-toggle custom dropdown-link pr-5" href="{{ url('/user') }}" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                         
							
							<span class="ml-3 user-img"><img src="@asset("images/about-img.png")" width="40"></span>
                        </a>
                          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item d-flex" href="{{ url('/user/dashboard') }}">
                                <img src="@asset("images/about-img.png")" width="30" class="mr-2 b-radius50">
                                <span>
                                    <p>Venkateswarao Karri</p>
                                    <small>Venkateswarao@ilms.com</small>
                                </span>
                            </a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="{{ url('/user/mycourses') }}"><img src="@asset("images/google-docs.png")" width="20" class="mr-3">My Courses</a>
                            
							<div class="dropdown-divider"></div>
							
							<?php /*
                            <a class="dropdown-item" href="#"><img src="@asset("images/heart.png")" width="20" class="mr-3">
                                My Whislist</a>
                            <div class="dropdown-divider"></div> 
							
                            <a class="dropdown-item" href="#">My Messages</a> */ ?>
							
							
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="{{ url('/user') }}"><img src="@asset("images/user.png")" width="20" class="mr-3">My Profile</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="{{ url('/user/logout') }}"><img src="@asset("images/logout.png")" width="20" class="mr-3"> Logout</a>
                        </div>
                    </li>
                   
                </nav>
            </div>
            <div class="inner-nav">
                <div class="container">
                    <nav class="navbar navbar-expand-md navbar-light p-0 py-2">
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                          <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarNav">
                            <ul class="navbar-nav">
                                <li class="nav-item active">
                                <a class="nav-link" href="{{ url('/') }}">Home</a>
                                </li>
                                <li class="nav-item">
                                <a class="nav-link" href="{{ url('/about_us') }}">About us</a>
                                </li>
                                <li class="nav-item">
                                <a class="nav-link" href="#">FAQs</a>
                                </li>
                                <li class="nav-item">
                                <a class="nav-link" href="#">Self Learning</a>
                                </li>
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle dropdown-link" href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        Student Programs
                                    </a>
                                    <div class="dropdown-menu" aria-labelledby="navbarDropdown1">
                                        <a class="dropdown-item" href="#">Program 1</a>
                                        <a class="dropdown-item" href="#">Program 2</a>
                                        <a class="dropdown-item" href="#">Program 3</a>
                                    </div>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#">Additional Resources</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="#">Live</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="{{ url('/contact_us') }}">Contact</a>
                                </li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
        </header>

        <main>